import { Component } from '@angular/core';

@Component({
  selector: 'app-member', // calling selector for member component
  templateUrl: './member.component.html',
  styleUrls: ['./member.component.css']
})
export class MemberComponent {
dataSource:any [] = [
  
];
displayedColumns: string[] = ['id', 'name', 'age', 'city'];
}
